// this is a new and better way to do app dev

/*var myApp = {}; //defining JS object, wrapper for content

(function(){

  "use strict";
  console.log("SEAF Fired");
  var menuBut = document.getElementById("#menu-button");


  function hideLogo() {
    var logo = document.getElementById("logoContain");

    if (logo.style.display === "block") {
        logo.style.display = "none";
    } else {
        x.style.display = "none";
    }

    console.log(menuBut);
}

  menuBut.addEventListener("click", hideLogo, false);


})();*/
