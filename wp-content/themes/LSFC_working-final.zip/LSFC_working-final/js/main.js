// this is a new and better way to do app dev

var myApp = {}; //defining JS object, wrapper for content 
